package kr.ac.dankook.ace.springbootwebmvcform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWebMvcFormApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootWebMvcFormApplication.class, args);
	}

}
