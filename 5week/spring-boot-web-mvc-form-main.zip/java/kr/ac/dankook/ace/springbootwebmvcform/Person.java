package kr.ac.dankook.ace.springbootwebmvcform;

public class Person {
	private String name; 
	private int age;
	private double weight;
	private double height;
	private Gender gender;	

	// for JPA only, no use
	public Person() {
	}

	public Person(String name, int age, double weight, double height, Gender gender) {
		this.name = name;
		this.age = age;
		this.weight = weight;
		this.height = height;
		this.gender = gender;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return this.age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public double getWeight() {
		return this.weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public double getHeight() {
		return this.height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	public Gender getGender() {
		return this.gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public Person name(String name) {
		setName(name);
		return this;
	}

	public Person age(int age) {
		setAge(age);
		return this;
	}

	public Person weight(double weight) {
		setWeight(weight);
		return this;
	}

	public Person height(double height) {
		setHeight(height);
		return this;
	}

	public Person gender(Gender gender) {
		setGender(gender);
		return this;
	}

	@Override
	public String toString() {
		return "{" +
			"name='" + getName() + "'" +
			", age='" + getAge() + "'" +
			", weight='" + getWeight() + "'" +
			", height='" + getHeight() + "'" +
			", gender='" + getGender() + "'" +
			"}";
	}


}
