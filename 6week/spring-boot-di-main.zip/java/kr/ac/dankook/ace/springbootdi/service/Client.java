package kr.ac.dankook.ace.springbootdi.service;

public interface Client {
    void doSomething();
}
