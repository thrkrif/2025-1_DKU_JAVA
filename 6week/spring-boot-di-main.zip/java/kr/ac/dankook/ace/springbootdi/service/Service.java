package kr.ac.dankook.ace.springbootdi.service;

public interface Service {
    String getInfo();
}
