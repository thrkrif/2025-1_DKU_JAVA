package kr.ac.dankook.ace.springbootdi.service;

public class ServiceG implements Service {

    @Override
    public String getInfo() {
        return "ServiceG's ServiceG's ServiceG's Info";
    }

}
